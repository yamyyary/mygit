<template>
  <div id="sublist" class="sublist">
    <h2 id="title"><a href="javascript:;" @click="back"><i class="iconfont icon-list1"></i></a>{{subListName}}</h2>
    <ul v-if="imgs.length" class="goods clearfix">
      <li v-for="(item, index) in storage" v-if="item.amount != 0">
        <a href="javascript:;" @click="viewDetail(item.id, subListName)"><div class="cover"><img :src="imgs[index]">
        </div></a><div class="li-bio"><p>{{item.name}}</p><span>￥{{item.price}}</span></div>
      </li>
    </ul>
    <div v-else class="nodata">缺货中 : (</div>
  </div>
</template>
<script>
import goods from '../data/storage.json'
export default {
  name: 'sublist',
  props: ['subListName'],
  data () {
    return {
      storage: null,
      imgs: []
    }
  },
  methods: {
    back () { this.$emit('backList') },
    viewDetail (id, belongs) { this.$emit('seeDetail', [id, belongs]) }
  },
  created () {
    this.storage = goods[this.subListName]
    if (this.storage != null && this.storage.length > 0) {
      let len = this.storage.length
      for (let i = 0; i < len; i++) {
        this.imgs[i] = require('../assets/image/' + this.storage[i].cover)
      }
    }
  }
}
</script>
<style>
.sublist{padding: 3rem 0;}
.sublist h2{position: sticky;top: -1px;z-index: 1;background-color: rgba(255,255,255,.84);font-family: "Microsoft JhengHei"; padding: .8rem 0 .8rem 1rem; border-left: 6px solid #41b883;}
.sublist h2 a{padding-right: .8rem;}
.goods{width: 100%;max-width: 48rem;margin: 4rem auto;}
.goods li{float: left;margin: 2rem 1rem;padding: 1rem;width: 12rem;transition: all .3s ease;position: relative;}
@media (max-width: 500px) {
  .goods li{width: 40%;margin: 2rem 0;}
}
.goods .cover{float: left;position: relative;height: 12rem;}
.li-bio{clear: both;color: #888;font-size: .9rem;text-align: left;}
.goods li img{display: block;max-height: 100%;max-width: 100%;}
.li-bio p{margin-bottom: .4rem;max-width: 100%;padding-top: 1rem;overflow: hidden;text-overflow: ellipsis;white-space: nowrap;}
.nodata{padding: 4rem 0;font-weight: bold;font-size: 2rem; color: #ccc;text-align: center;}
</style>
