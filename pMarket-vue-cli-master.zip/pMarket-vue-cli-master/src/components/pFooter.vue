<template>
  <footer class="footer">
    <div class="footer-btns">
      <a href="javascript:;" :class="[cartShow ? 'f-active' : '', 'footer-btn']" @click="toggleCart"><i class="iconfont icon-cart"></i></a>
      <div class="window" v-show="cartShow">
        <header><a href="javascript:;" v-if="cartList.length > 0">去支付</a>购物车</header>
        <ul v-if="cartList.length > 0">
          <a href="javascript:;"><li>苏东坡传 * 1<a href="javascript:;"><i class="iconfont icon-delete"></i></a></li></a>
          <a href="javascript:;"><li>朱元璋传 * 2<a href="javascript:;"><i class="iconfont icon-delete"></i></a></li></a>
        </ul>
        <div class="nolist" v-else><b>购物车很空！</b></div>
      </div>
    </div>
    <div class="footer-btns">
      <a href="javascript:;" :class="[favShow ? 'f-active' : '', 'footer-btn']" @click="toggleFav"><i class="iconfont icon-favourite"></i></a>
      <div class="window" v-show="favShow">
        <header>收藏夹</header>
        <ul v-if="favList[0]">
          <a v-for="item in favList" href="javascript:;" @click="viewDetail(item.id, item.belongs)"><li>{{item.name}}<a href="javascript:;"><i class="iconfont icon-delete"></i></a></li></a>
        </ul>
        <div v-else class="nolist"><b>还未收藏任何商品</b></div>
      </div>
    </div>
  </footer>
</template>
<script>
export default {
  name: 'footer',
  props: ['favLists'],
  data () {
    return {
      favShow: false,
      cartShow: false,
      favList: this.favLists,
      cartList: []
    }
  },
  methods: {
    toggleFav () {
      this.cartShow = false
      this.favShow = !this.favShow
    },
    toggleCart () {
      this.favShow = false
      this.cartShow = !this.cartShow
    },
    viewDetail (id, belongs) { this.$emit('seeDetail', [id, belongs]) }
  }
}
</script>
<style>
  .footer{position: fixed;left: 0;bottom: 0;width: 100%;background-color: rgba(255,255,255,.86);box-shadow: 0 0 6px #aaa;}
  .footer-btns{float: right;}
  .footer-btn{display: block;padding: 6px 14px;line-height: 1.2;position: relative;}
  .footer-btn:hover, .f-active{background-color: #41b883;color: #fff;}
  .footer-btn:after{display: none;content:'\20';position: absolute;top: -.5rem;right: 1rem;border-top: .5rem solid #41b883;border-left: .5rem solid transparent;border-right: .5rem solid transparent;}
  .f-active:after{display: block}
  .window{position: absolute;bottom: 3rem;right: 0;width: 100%;max-width: 40rem;min-height: 4rem;background-color: rgba(255,255,255,.94);box-shadow: 0 0 6px #aaa;border-bottom: 3px solid #41b883;padding: .4rem 0;text-align: right;}
  .window header{padding: .2rem 1rem .2rem 0;border-right: 6px solid #41b883;margin-bottom: .3rem;}
  .window header a{padding: .2rem .6rem;background-color: #41b883;color: #fff;float: left;}
  .window li{padding: .4rem 1.4rem .4rem .4rem;font-size: .88rem;overflow: hidden;text-overflow: ellipsis;white-space: nowrap;}
  .window li:hover{background-color: #41b883;color: #fff;}
  .window li a{float: left;opacity: 0;margin-left: .2rem;}
  .window li:hover a{opacity: 1;color: #fff;}
  .iconfont{font-size: 1.6rem;}
  .nolist{font-size: 1.2rem;text-align: center;margin: 1rem 0 2rem 0;color: #aaa;letter-spacing: .2rem;}
</style>
