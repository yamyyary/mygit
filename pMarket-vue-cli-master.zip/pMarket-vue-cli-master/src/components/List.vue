<template>
  <div id="list" class="list">
    <div v-for="item in menu">
      <h3><span>{{ item.name }}</span></h3>
      <ul class="clearfix">
        <a href="javascript:;" v-for="i in item.subs" @click="subList(i)"><li>{{ i }}</li></a>
      </ul>
    </div>
  </div>
</template>
<script>
import menu from '../data/menu.json'
export default {
  name: 'list',
  data () {
    return {
      menu: menu
    }
  },
  methods: {
    subList (name) { this.$emit('subTab', name) }
  }
}
</script>
<style>
.list{margin-top: 2rem;padding: 20px 0;}
.list h3{color: #666;position: sticky; top: -1px;background-color: #fff;text-align: center;letter-spacing: .2rem;padding: .5rem 0;}
.list h3 span{padding: .4rem 0;border-bottom: 3px solid #41b883;}
.list ul{margin: 1.5rem auto;padding: 20px 0 100px 0;text-align: center;width: 100%;max-width: 900px;}
.list ul li{display: inline-block;margin: .2rem 0; padding: 8px 20px;transition: all .3s ease;border-bottom: 3px solid #eee;}
.list ul li:hover{background-color: #41b883;color: #fff;border-color: #2e9466;}
</style>
