<template>
  <div id="banner" class="banner"></div>
</template>
<style>
.banner{height: 10rem; background: #41b883;margin-top: 2rem;box-shadow: 0 0 6px #aaa;}
</style>
<script>
</script>
