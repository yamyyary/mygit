<template>
  <div id="detail" class="detail clearfix">
    <a href="javascript:;" @click="back" class="back"><i class="iconfont icon-delete"></i></a>
    <div class="clearfix">
      <img :src="cover" class="cover">
      <div class="info">
        <h3>{{o.name}}</h3>
        <p><b>{{o.author}}</b> 著</p>
        <p>￥<b>{{o.price}}</b></p>
        <p>余 <b>{{o.amount}}</b> 本</p>
        <div class="shop">
          <a href="javascript:;" :class="[number <= 0 ? 'disabled' : '', 'opt']" @click="decNum"><i class="iconfont icon-desc"></i></a>
          <input type="number" min="0" :max="o.amount" name="amount" v-model.number="number">
          <a href="javascript:;" :class="[number >= amount ? 'disabled' : '', 'opt']" @click="incNum"><i class="iconfont icon-add"></i></a>
          <div class="clearfix">
            <a href="javascript:;" :class="[number <= 0 ? 'disabled' : '', 'goods-opt']">加入购物车</a>
            <a href="javascript:;" :class="[isFav ? 'disabled' : '', 'goods-opt']" @click="fav(o.id, o.name, subListName)">{{ isFav? '已': ''}}收藏</a>
          </div>
        </div>
      </div>
    </div>
    <div class="goods-bio">
      <h3>简介</h3>
      <p>{{o.substract}}</p>
    </div>
  </div>
</template>
<script>
import storage from '../data/storage.json'
export default {
  name: 'detail',
  props: ['goods', 'subListName', 'favList'],
  data () {
    return {
      o: null,
      number: 1,
      cover: null,
      isFav: false,
      amount: 0
    }
  },
  methods: {
    back () { this.$emit('backSubList') },
    incNum () { this.number = this.number < this.amount ? this.number + 1 : this.number },
    decNum () { this.number = this.number < 1 ? 0 : this.number - 1 },
    fav (id, name, belongs) {
      this.isFav = !this.isFav
      this.$emit('favGoods', [id, belongs, this.isFav, name])
    }
  },
  created () {
    this.o = storage[this.goods[1]]
    let l = this.o.length
    for (let i = 0; i < l; i++) {
      if (this.o[i].id === this.goods[0]) {
        this.o = this.o[i]
        this.cover = require('../assets/image/' + this.o.cover)
        this.amount = this.o.amount
        return
      }
    }
  }
}
</script>
<style>
.back{position: sticky;left: -1px;top: -1px;padding: .4rem;background-color: rgba(255,255,255,.86);z-index: 1;}
.detail{padding: 2rem 3% 4rem 3%;width: 60%;margin: 2rem auto;}
.cover{float: left;max-width: 12rem;max-height: 20rem;display: block;}
.info{display: block;text-align: right;min-height: 20rem;position: relative;margin-top: 2rem;}
.info h3{margin-bottom: 2rem;}
.info p{margin: .6rem 0;color: #777;}
.info b{color: #444;}
.goods-bio{clear: both;margin: 4rem 0;letter-spacing: .1rem;}
.goods-bio h3{padding: .2rem 0 .2rem 1rem;border-left: 6px solid #41b883;margin-bottom: 2rem;}
.shop{position: absolute;right: 0;bottom: .6rem;text-align: right;}
.opt{background-color: #41b883;color: #fff;font-size: 1.5rem;border-radius: 4px;padding: 0 .2rem;}
.goods-opt{float: right;margin-left: .8rem;font-size: 1rem;padding: .3rem .6rem;margin-top: .6rem;background-color: #41b883;color: #fff;border-radius: 4px;text-align: center;letter-spacing: .2rem;}
.disabled{background-color: #ddd;color: #666;}
.shop input{outline: none;padding: 0 .6rem .4rem .6rem;text-align: center;}
input::-webkit-outer-spin-button,input::-webkit-inner-spin-button{-webkit-appearance: none;}
input[type="number"]{-moz-appearance:textfield;}
@media (max-width: 760px) {
  .detail{padding: 3rem 3%;width: 94%;}
  .cover{margin-top: 2rem;}
  .info{clear: both;margin: 2rem 0 0 0;float: left;text-align: left;min-height: 0;width: 100%;}
}
</style>
