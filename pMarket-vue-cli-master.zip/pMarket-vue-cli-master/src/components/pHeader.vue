<template>
  <header id="header" class="header clearfix">
    <h2 class="clearfix"><router-link to="/">pMarket</router-link></h2>
    <ul class="nav">
      <li :class="{ active: onCatalog }"><router-link to="/catalog">商 品</router-link></li>
    </ul>
    <a href="javascript:;" class="user">登 入</a>
  </header>
</template>
<style>
  .header{line-height: 1;}
  .header h2{float: left;font-family: 'Segoe Print';padding-top: .625rem; margin: 0 1.25rem; }
  .header a{color: #41b883;}
  .nav{float: left;}
  .nav a{color: #41b883;}
  .nav li a{float: left;padding: .8rem 1.25rem;transition: all .3s ease;position: relative;border-bottom: 4px solid transparent;font: bold 1rem "Microsoft JhengHei";}
  .nav .active a, .nav li a:hover{background-color: #41b883;color: #fff;box-shadow: 0 0 6px #aaa;}
  .user{float: right;padding: .6rem .8rem;margin: .4rem;}
  .user:hover{box-shadow: 0 0 6px #aaa;background-color: #41b883;color: #fff;}
</style>
<script>
export default{
  name: 'header',
  data () {
    return {
      user: 'Micky'
    }
  },
  props: ['onCatalog']
}
</script>
