<template>
  <div id="catalog">
    <pheader :on-catalog="onCatalog"></pheader>
    <component :subListName="subListName" :goods="goods" :favLists="favList" @favGoods="fav" @subTab="toggleTab" @seeDetail="viewDetail" @backList="backToList" @backSubList="backToSubList" :is="currentPage" keep-alive transition="slide" transition-mode="out-in"></component>
    <pfooter :favLists="favList" @seeDetail="viewDetail"></pfooter>
  </div>
</template>
<script>
import pheader from '../components/pHeader'
import pfooter from '../components/pFooter'
import list from '../components/List'
import sublist from '../components/SubList'
import detail from '../components/Detail'
export default {
  name: 'catalog',
  data () {
    return {
      currentPage: 'list',
      onCatalog: true,
      subListName: '',
      goods: null,
      favList: []
    }
  },
  methods: {
    toggleTab (name) {
      this.currentPage = 'sublist'
      this.subListName = name
    },
    backToList () { this.currentPage = 'list' },
    viewDetail (o) {
      this.goods = o
      this.currentPage = 'detail'
    },
    backToSubList () { this.currentPage = 'sublist' },
    fav (o) {
      if (o[2]) {
        this.favList.push({ 'id': o[0], 'name': o[3], 'belongs': o[1] })
      } else {
        let l = this.favList.length
        for (let i = 0; i < l; i++) {
          if (this.favList[i].id === o[0]) {
            this.favList.splice(i, 1)
          }
        }
      }
    }
  },
  components: {
    pheader,
    list,
    sublist,
    detail,
    pfooter
  }
}
</script>
