<template>
  <div class="container">
    <pheader></pheader>
    <banner></banner>
  </div>

</template>

<script>
import pheader from '../components/pHeader'
import banner from '../components/Banner'

export default {
  name: 'index',
  components: {
    pheader,
    banner
  }
}

</script>

<style>
</style>
