# pmarket-vue-cli

## 开始

安装依赖包：
npm install

运行项目：
npm start

## 界面截图

### 主页界面内容忽略，下面是进入商品分类界面：
![pmarket](https://raw.githubusercontent.com/MunGaaKei/pMarket/master/src/assets/pages/2.png)

             
### 进入类别目录：
![pmarket](https://raw.githubusercontent.com/MunGaaKei/pMarket/master/src/assets/pages/4.png)


### 进入商品详情界面：
![pmarket](https://raw.githubusercontent.com/MunGaaKei/pMarket/master/src/assets/pages/5.png)

### 移动端界面：
![pmarket](https://raw.githubusercontent.com/MunGaaKei/pMarket/master/src/assets/pages/6.png)



### 收藏夹：
![pmarket](https://raw.githubusercontent.com/MunGaaKei/pMarket/master/src/assets/pages/7.png)

### 收藏商品：
![pmarket](https://raw.githubusercontent.com/MunGaaKei/pMarket/master/src/assets/pages/8.png)
